/*
 * MacroModel atom typing
 *
 * (c) Schrodinger, Inc.
 */

#include "AtomInfo.h"

int getMacroModelAtomType(const AtomInfoType * ai);
