/*
 * Mol2 atom typing
 *
 * (c) Schrodinger, Inc.
 */

#include "ObjectMolecule.h"

const char * getMOL2Type(ObjectMolecule * obj, int atm);
