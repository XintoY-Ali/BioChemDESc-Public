

#ifndef _H_sort
#define _H_sort

void  SortIntIndex(int n,int *v,int *i);

#endif
