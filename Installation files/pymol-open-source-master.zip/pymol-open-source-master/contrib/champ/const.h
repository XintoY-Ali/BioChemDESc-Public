#ifndef _H_const
#define _H_const

/* numeric tools */

#define c_small4   (1e-4)
#define c_small8   (1e-8)
#define c_small12  (1e-12)

#endif
