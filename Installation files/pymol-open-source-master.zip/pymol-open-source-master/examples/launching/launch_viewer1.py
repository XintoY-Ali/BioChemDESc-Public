
# Tell PyMOL we don't want any GUI features.

import pymol
pymol.finish_launching([ 'pymol', '-qxi' ])
