
# Importing the PyMOL module will create the window.

import pymol

# Call the function below before using any PyMOL modules.

pymol.finish_launching()
